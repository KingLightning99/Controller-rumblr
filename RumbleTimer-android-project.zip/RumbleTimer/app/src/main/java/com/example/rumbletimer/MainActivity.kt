package com.example.rumbletimer

import android.app.Activity
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.os.CombinedVibration
import android.os.CountDownTimer
import android.os.VibrationEffect
import android.os.Vibrator
import android.text.InputType
import android.view.Gravity
import android.view.InputDevice
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var clock: TextView
    private lateinit var status: TextView
    private lateinit var minEdit: EditText
    private lateinit var secEdit: EditText
    private lateinit var startBtn: Button

    private var timer: CountDownTimer? = null
    private var running = false
    private var remainingMs = 0L

    private val pattern = longArrayOf(0, 600, 300, 600, 300, 600)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Keep the screen on so the timer isn't interrupted
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        buildUi()
        showTime(inputMs())
        refreshStatus()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(48), dp(24), dp(24))
        }
        root.addView(TextView(this).apply { text = "Rumble timer"; textSize = 24f })
        status = TextView(this).apply { textSize = 14f; setPadding(0, dp(4), 0, dp(16)) }
        root.addView(status)

        clock = TextView(this).apply {
            textSize = 64f
            gravity = Gravity.CENTER
            setPadding(0, dp(24), 0, dp(24))
        }
        root.addView(clock)

        val inputs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        minEdit = numberField("Minutes", "5")
        secEdit = numberField("Seconds", "0")
        inputs.addView(minEdit, LinearLayout.LayoutParams(0, -2, 1f))
        inputs.addView(secEdit, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(inputs)

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        startBtn = Button(this).apply { text = "Start"; setOnClickListener { toggle() } }
        val reset = Button(this).apply { text = "Reset"; setOnClickListener { reset() } }
        row.addView(startBtn, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(reset, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(row)

        val test = Button(this).apply {
            text = "Test rumble"
            setOnClickListener { refreshStatus(); rumble() }
        }
        root.addView(test)

        setContentView(root)
    }

    private fun numberField(hintText: String, initial: String) = EditText(this).apply {
        hint = hintText
        setText(initial)
        inputType = InputType.TYPE_CLASS_NUMBER
        gravity = Gravity.CENTER
    }

    private fun inputMs(): Long {
        val m = minEdit.text.toString().toLongOrNull() ?: 0L
        val s = secEdit.text.toString().toLongOrNull() ?: 0L
        return (m * 60 + s) * 1000
    }

    private fun showTime(ms: Long) {
        val total = (ms + 999) / 1000
        clock.text = "%02d:%02d".format(total / 60, total % 60)
    }

    private fun toggle() {
        if (running) {
            timer?.cancel()
            running = false
            startBtn.text = "Resume"
            return
        }
        if (remainingMs <= 0) remainingMs = inputMs()
        if (remainingMs <= 0) return
        running = true
        startBtn.text = "Pause"
        timer = object : CountDownTimer(remainingMs, 200) {
            override fun onTick(left: Long) { remainingMs = left; showTime(left) }
            override fun onFinish() {
                running = false
                remainingMs = 0
                startBtn.text = "Start"
                showTime(0)
                rumble()
            }
        }.start()
    }

    private fun reset() {
        timer?.cancel()
        running = false
        remainingMs = 0
        startBtn.text = "Start"
        showTime(inputMs())
    }

    private fun gamepads(): List<InputDevice> =
        InputDevice.getDeviceIds().mapNotNull { InputDevice.getDevice(it) }.filter {
            val s = it.sources
            (s and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD ||
                (s and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
        }

    private fun refreshStatus() {
        val pads = gamepads()
        status.text = if (pads.isEmpty()) "No controller found. Connect it and press a button."
        else "Connected: " + pads.first().name
    }

    @Suppress("DEPRECATION")
    private fun rumble() {
        var count = 0
        for (dev in gamepads()) {
            try {
                if (Build.VERSION.SDK_INT >= 31) {
                    val vm = dev.vibratorManager
                    if (vm.vibratorIds.isNotEmpty()) {
                        vm.vibrate(CombinedVibration.createParallel(
                            VibrationEffect.createWaveform(pattern, -1)))
                        count++
                    }
                } else {
                    val v = dev.vibrator
                    if (v.hasVibrator()) {
                        v.vibrate(VibrationEffect.createWaveform(pattern, -1))
                        count++
                    }
                }
            } catch (e: Exception) { /* try the next device */ }
        }
        if (count == 0) {
            // Fallback: vibrate the phone itself
            val phone = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            phone.vibrate(VibrationEffect.createWaveform(pattern, -1))
            status.text = "Controller can't rumble from this app. Vibrated the phone instead."
        } else {
            status.text = "Rumbled $count controller(s)."
        }
    }

    override fun onDestroy() {
        timer?.cancel()
        super.onDestroy()
    }
}
